# Marine InVEST: Compare Vulnerability
# Author: Gregg Verutes
# 08/13/12

# import modules
import sys, string, os, array, numpy, datetime
from math import *
from scipy import stats
import arcgisscripting
import fpformat, operator

# create the geoprocessor object
gp = arcgisscripting.create()
# set output handling
gp.OverwriteOutput = 1
# check out any necessary extensions
gp.CheckOutExtension("spatial")

# error messages
msgArguments = "\nProblem with arguments."

# percentiles list (25, 75, 10, 20, 30, 40, 50, 60, 70, 80, 90)
def getPercentiles(list):
    PctList = []
    PctList.append(stats.scoreatpercentile(list, 25))
    PctList.append(stats.scoreatpercentile(list, 75))
    PctList.append(stats.scoreatpercentile(list, 10))
    PctList.append(stats.scoreatpercentile(list, 20))
    PctList.append(stats.scoreatpercentile(list, 30))
    PctList.append(stats.scoreatpercentile(list, 40))
    PctList.append(stats.scoreatpercentile(list, 50))
    PctList.append(stats.scoreatpercentile(list, 60))
    PctList.append(stats.scoreatpercentile(list, 70))
    PctList.append(stats.scoreatpercentile(list, 80))
    PctList.append(stats.scoreatpercentile(list, 90))                                       
    return PctList


try:
    # get parameters
    TextOutput = gp.GetParameterAsText(0)
    VulnField = gp.GetParameterAsText(1)
    S1_Output = gp.GetParameterAsText(2)
    S2_Output = gp.GetParameterAsText(3)
    S3_Output = gp.GetParameterAsText(4)
    S4_Output = gp.GetParameterAsText(5)
    S5_Output = gp.GetParameterAsText(6)
    S6_Output = gp.GetParameterAsText(7)
except:
    raise Exception, msgArguments + gp.GetMessages(2)


##########################################
######## CALCULATE PCTILE BREAKS #########
##########################################

gp.AddMessage("\nReading inputs and calculating percentile breaks...")

VIList = []
PathList = [S1_Output, S2_Output]
if S3_Output:
    PathList.append(S3_Output)
if S4_Output:
    PathList.append(S4_Output)
if S5_Output:
    PathList.append(S5_Output)
if S6_Output:
    PathList.append(S6_Output)
    
for i in range(0,len(PathList)):
    cur = gp.UpdateCursor(PathList[i])
    row = cur.Next()
    while row:
        CellCount = int(row.GetValue("COUNT"))
        for k in range(CellCount):
            VIList.append(row.GetValue(VulnField))
        cur.UpdateRow(row)
        row = cur.next()
    del row, cur

# get pctile breaks
VIPctList = getPercentiles(VIList)

# add pctile breaks message
gp.AddMessage("\nPercentile...")
gp.AddMessage("25th Percentile: "+str(VIPctList[0]))
gp.AddMessage("75th Percentile: "+str(VIPctList[1]))
gp.AddMessage("\n10th Percentile: "+str(VIPctList[2]))
gp.AddMessage("20th Percentile: "+str(VIPctList[3]))
gp.AddMessage("30th Percentile: "+str(VIPctList[4]))
gp.AddMessage("40th Percentile: "+str(VIPctList[5]))
gp.AddMessage("50th Percentile: "+str(VIPctList[6]))
gp.AddMessage("60th Percentile: "+str(VIPctList[7]))
gp.AddMessage("70th Percentile: "+str(VIPctList[8]))
gp.AddMessage("80th Percentile: "+str(VIPctList[9]))
gp.AddMessage("90th Percentile: "+str(VIPctList[10]))

# write pctile breaks to text file
gp.AddMessage("\nWriting percentile breaks to text file...")
gp.AddMessage("\nText file location: "+TextOutput)
now = datetime.datetime.now()
breaksfile = open(TextOutput,"w") 
breaksfile.writelines("TALLY BREAKS")
breaksfile.writelines("\nDate and Time: "+ now.strftime("%Y-%m-%d %H:%M"))
breaksfile.writelines("\n____________\n")
breaksfile.writelines("\nVulnerability field used: "+VulnField)
breaksfile.writelines("\nScenarios included: ")
breaksfile.writelines("\n1) "+S1_Output)
breaksfile.writelines("\n2) "+S2_Output)
if S3_Output:
    breaksfile.writelines("\n3) "+S3_Output)
if S4_Output:
    breaksfile.writelines("\n4) "+S4_Output)
if S5_Output:
    breaksfile.writelines("\n5) "+S5_Output)
if S6_Output:
    breaksfile.writelines("\n6) "+S6_Output)
breaksfile.writelines("\n____________\n")
breaksfile.writelines("\n25th Percentile: "+str(VIPctList[0]))
breaksfile.writelines("\n75th Percentile: "+str(VIPctList[1]))
breaksfile.writelines("\n")
breaksfile.writelines("\n10th Percentile: "+str(VIPctList[2]))
breaksfile.writelines("\n20th Percentile: "+str(VIPctList[3]))
breaksfile.writelines("\n30th Percentile: "+str(VIPctList[4]))
breaksfile.writelines("\n40th Percentile: "+str(VIPctList[5]))
breaksfile.writelines("\n50th Percentile: "+str(VIPctList[6]))
breaksfile.writelines("\n60th Percentile: "+str(VIPctList[7]))
breaksfile.writelines("\n70th Percentile: "+str(VIPctList[8]))
breaksfile.writelines("\n80th Percentile: "+str(VIPctList[9]))
breaksfile.writelines("\n90th Percentile: "+str(VIPctList[10]))
breaksfile.close()