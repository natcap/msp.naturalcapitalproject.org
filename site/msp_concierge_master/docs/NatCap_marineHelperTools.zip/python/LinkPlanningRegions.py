# Marine InVEST: Link Output to Planning Regions
# Author: Gregg Verutes
# 08/20/12

# import modules
import sys, string, os, datetime
import arcgisscripting
from math import *

# create the geoprocessor object
gp = arcgisscripting.create()
# set output handling
gp.OverwriteOutput = 1
# check out any necessary extensions
gp.CheckOutExtension("management")
gp.CheckOutExtension("analysis")

# error messages
msgArguments = "\nProblem with arguments."

try:
    try:
        # get parameters
        inputFC = gp.GetParameterAsText(0)
        PRegions = gp.GetParameterAsText(1)
        PR_IDField = gp.GetParameterAsText(2)
        outputFC = gp.GetParameterAsText(3)
    except:
        raise Exception, msgArguments + gp.GetMessages(2)


    gp.workspace = outputFC[:-(1+len(outputFC.split("\\")[-1]))]
    PRegions_Diss = gp.workspace + "\\PRegions_Diss.shp"
    gp.Extent = "MAXOF"


    ##############################################
    ###### COMMON FUNCTION AND CHECK INPUTS ######
    ##############################################

    def AddField(FileName, FieldName, Type, Precision, Scale):
        fields = gp.ListFields(FileName, FieldName)
        field_found = fields.Next()
        if field_found:
            gp.DeleteField_management(FileName, FieldName)
        gp.AddField_management(FileName, FieldName, Type, Precision, Scale, "", "", "NON_NULLABLE", "NON_REQUIRED", "")
        return FileName


    ###########################################

    # dissolve and find area of planning regions
    gp.AddMessage("\nDissolving planning regions based on identifier field...")
    gp.Dissolve_management(PRegions,  PRegions_Diss, PR_IDField)
    PRegions_Diss = AddField(PRegions_Diss, "AREA", "FLOAT", "0", "0")
    gp.CalculateField_management(PRegions_Diss, "AREA", "!shape.area@squarekilometers!", "PYTHON", "")

    # perform spatial join
    gp.AddMessage("\nJoining attributes for each region that intersect the input feature class...")
    gp.SpatialJoin_analysis(inputFC, PRegions_Diss, outputFC, "JOIN_ONE_TO_ONE", "KEEP_ALL", "", "INTERSECT", "", "")  ## ADD OPTION OF "CLOSEST"

    # delete intermediate data
    gp.delete_management(PRegions_Diss)
    gp.AddMessage("")
    del gp

except Exception, ErrorDesc:
    gp.AddMessage(gp.GetMessages())