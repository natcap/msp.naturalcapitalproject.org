# Marine InVEST: Risk Summaries
# Author: Gregg Verutes
# 08/13/12

# import modules
import sys, string, os, datetime, csv
import arcgisscripting
from math import *

# create the geoprocessor object
gp = arcgisscripting.create()
# set output handling
gp.OverwriteOutput = 1
# check out any necessary extensions
gp.CheckOutExtension("management")
gp.CheckOutExtension("analysis")
gp.CheckOutExtension("conversion")
gp.CheckOutExtension("spatial")

# error messages
msgArguments = "\nProblem with arguments."
msgNumPyNo = "NumPy extension is required to run the Coastal Vulnerability Model.  Please consult the Marine InVEST FAQ for instructions on how to install."

# import modules
try:
    import numpy as np
except:
    gp.AddError(msgNumPyNo)
    raise Exception

try:
    # get parameters
    parameters = []
    now = datetime.datetime.now()
    parameters.append("Date and Time: "+ now.strftime("%Y-%m-%d %H:%M"))
    gp.workspace = gp.GetParameterAsText(0)
    parameters.append("Workspace: "+ gp.workspace)
    ZonesScenarioStr = gp.GetParameterAsText(1)
    parameters.append("Scenario Name: "+ ZonesScenarioStr)  
    PRegions = gp.GetParameterAsText(2)
    parameters.append("Planning Regions Layer: "+ PRegions)
    PR_IDField = gp.GetParameterAsText(3)
    parameters.append("Planning Regions Identifier Field: "+ PR_IDField)
    Mangrove = gp.GetParameterAsText(4)
    parameters.append("Mangrove Layer: "+ Mangrove)
    Coral = gp.GetParameterAsText(5)
    parameters.append("Coral Layer: "+ Coral)
    Seagrass = gp.GetParameterAsText(6)
    parameters.append("Seagrass Layer: "+ Seagrass)
    delIntermediate = gp.GetParameterAsText(7)
    parameters.append("Delete Intermediate Files? "+ delIntermediate)  
except:
    raise Exception, msgArguments + gp.GetMessages(2)

try:
    thefolders=["intermediate","Output"]
    for folder in thefolders:
        if not gp.exists(gp.workspace+folder):
            gp.CreateFolder_management(gp.workspace, folder)
except:
    raise Exception, "Error creating folders"

# local variables 
outputws = gp.workspace + os.sep + "Output" + os.sep
interws = gp.workspace + os.sep + "intermediate" + os.sep

MangroveDissolve = interws + "MangroveDissolve.shp"
unionMangroveZones = interws + "unionMangroveZones.shp"
CoralDissolve = interws + "CoralDissolve.shp"
unionCoralZones = interws + "unionCoralZones.shp"
SeagrassDissolve = interws + "SeagrassDissolve.shp"
unionSeagrassZones = interws + "unionSeagrassZones.shp"

PlanningRegions = outputws + "PlanningRegions.shp"
MangroveZones = outputws + "MangroveZones.shp"
CoralZones = outputws + "CoralZones.shp"
SeagrassZones = outputws + "SeagrassZones.shp"

##############################################
###### COMMON FUNCTION AND CHECK INPUTS ######
##############################################

def AddField(FileName, FieldName, Type, Precision, Scale):
    fields = gp.ListFields(FileName, FieldName)
    field_found = fields.Next()
    if field_found:
        gp.DeleteField_management(FileName, FieldName)
    gp.AddField_management(FileName, FieldName, Type, Precision, Scale, "", "", "NON_NULLABLE", "NON_REQUIRED", "")
    return FileName

def ckProjection(data):
    dataDesc = gp.describe(data)
    spatreflc = dataDesc.SpatialReference
    if spatreflc.Type <> 'Projected':
        gp.AddError(data +" does not appear to be projected.  It is assumed to be in meters.")
        raise Exception
    if spatreflc.LinearUnitName <> 'Meter':
        gp.AddError("This model assumes that "+data+" is projected in meters for area calculations.  You may get erroneous results.")
        raise Exception


###########################################
######## CHECK INPUTS & DATA PREP #########
###########################################

gp.AddMessage("\nChecking and preparing the inputs...")
ckProjection(PRegions)
ckProjection(Mangrove)
ckProjection(Coral)
ckProjection(Seagrass)

gp.Dissolve_management(PRegions, PlanningRegions, PR_IDField)

# area of input 'Zones'
PlanningRegions = AddField(PlanningRegions, "AREA", "FLOAT", "0", "0")
gp.CalculateField_management(PlanningRegions, "AREA", "!shape.area@squarekilometers!", "PYTHON", "")

# create 'AreaStatsArray' to store calcs
AreaStatsArray = []
for i in range(gp.GetCount_management(PlanningRegions)):
    AreaStatsArray.append([0]*11)

PR_IDFieldList = []  
cur = gp.UpdateCursor(PlanningRegions)
row = cur.Next()
count = 0
while row:
    PR_IDFieldList.append(row.GetValue(PR_IDField))
    AreaStatsArray[count][0] = row.GetValue(PR_IDField)
    AreaStatsArray[count][1] = round(row.GetValue("AREA"), 2)
    count += 1
    row = cur.next()
del row, cur

gp.AddMessage("\nCalculating area of habitat within each planning region...")  
gp.Extent = PlanningRegions

# mangroves
PlanningRegions = AddField(PlanningRegions, "MANGRV", "SHORT", "0", "0")
gp.CalculateField_management(PlanningRegions, "MANGRV", "1", "VB")
gp.Dissolve_management(Mangrove, MangroveDissolve, "RISK_QUAL")
MangroveDissolve = AddField(MangroveDissolve, "ZONES", "SHORT", "0", "0")
gp.CalculateField_management(MangroveDissolve, "ZONES", "1", "VB")
UnionMangroveExpr =  MangroveDissolve+" 1; "+PlanningRegions+" 2"        
gp.Union_analysis(UnionMangroveExpr, unionMangroveZones)
gp.Select_analysis(unionMangroveZones, MangroveZones, "\"ZONES\" = 1 AND \"MANGRV\" = 1")
MangroveZones = AddField(MangroveZones, "AREA", "FLOAT", "0", "0")
gp.CalculateField_management(MangroveZones, "AREA", "!shape.area@squarekilometers!", "PYTHON", "")
cur = gp.UpdateCursor(MangroveZones)
row = cur.Next()
while row:
    indexID = PR_IDFieldList.index(row.GetValue(PR_IDField))
    if row.GetValue("RISK_QUAL") == 'Medium':
        AreaStatsArray[indexID][3] = AreaStatsArray[indexID][3] + row.GetValue("AREA")
    elif row.GetValue("RISK_QUAL") == 'High':
        AreaStatsArray[indexID][4] = AreaStatsArray[indexID][4] + row.GetValue("AREA")
    else:
        AreaStatsArray[indexID][2] = AreaStatsArray[indexID][2] + row.GetValue("AREA")
    cur.UpdateRow(row)
    row = cur.next()
del row, cur
    
# corals
PlanningRegions = AddField(PlanningRegions, "CORAL", "SHORT", "0", "0")
gp.CalculateField_management(PlanningRegions, "CORAL", "1", "VB")
gp.Dissolve_management(Coral, CoralDissolve, "RISK_QUAL")
CoralDissolve = AddField(CoralDissolve, "ZONES", "SHORT", "0", "0")
gp.CalculateField_management(CoralDissolve, "ZONES", "1", "VB")
UnionCoralExpr =  CoralDissolve+" 1; "+PlanningRegions+" 2"        
gp.Union_analysis(UnionCoralExpr, unionCoralZones)
gp.Select_analysis(unionCoralZones, CoralZones, "\"ZONES\" = 1 AND \"CORAL\" = 1")
CoralZones = AddField(CoralZones, "AREA", "FLOAT", "0", "0")
gp.CalculateField_management(CoralZones, "AREA", "!shape.area@squarekilometers!", "PYTHON", "")
cur = gp.UpdateCursor(CoralZones)
row = cur.Next()
while row:
    indexID = PR_IDFieldList.index(row.GetValue(PR_IDField))
    if row.GetValue("RISK_QUAL") == 'Medium':
        AreaStatsArray[indexID][6] = AreaStatsArray[indexID][6] + row.GetValue("AREA")
    elif row.GetValue("RISK_QUAL") == 'High':
        AreaStatsArray[indexID][7] = AreaStatsArray[indexID][7] + row.GetValue("AREA")
    else:
        AreaStatsArray[indexID][5] = AreaStatsArray[indexID][5] + row.GetValue("AREA")
    cur.UpdateRow(row)
    row = cur.next()
del row, cur
    
# seagrass
PlanningRegions = AddField(PlanningRegions, "SEAGRASS", "SHORT", "0", "0")
gp.CalculateField_management(PlanningRegions, "SEAGRASS", "1", "VB")
gp.Dissolve_management(Seagrass, SeagrassDissolve, "RISK_QUAL")
SeagrassDissolve = AddField(SeagrassDissolve, "ZONES", "SHORT", "0", "0")
gp.CalculateField_management(SeagrassDissolve, "ZONES", "1", "VB")
UnionSeagrassExpr =  SeagrassDissolve+" 1; "+PlanningRegions+" 2"        
gp.Union_analysis(UnionSeagrassExpr, unionSeagrassZones)
gp.Select_analysis(unionSeagrassZones, SeagrassZones, "\"ZONES\" = 1 AND \"SEAGRASS\" = 1")
SeagrassAreaZones = AddField(SeagrassZones, "AREA", "FLOAT", "0", "0")
gp.CalculateField_management(SeagrassZones, "AREA", "!shape.area@squarekilometers!", "PYTHON", "")
cur = gp.UpdateCursor(SeagrassZones)
row = cur.Next()
while row:
    indexID = PR_IDFieldList.index(row.GetValue(PR_IDField))
    if row.GetValue("RISK_QUAL") == 'Medium':
        AreaStatsArray[indexID][9] = AreaStatsArray[indexID][9] + row.GetValue("AREA")
    elif row.GetValue("RISK_QUAL") == 'High':
        AreaStatsArray[indexID][10] = AreaStatsArray[indexID][10] + row.GetValue("AREA")
    else:
        AreaStatsArray[indexID][8] = AreaStatsArray[indexID][8] + row.GetValue("AREA")
    cur.UpdateRow(row)
    row = cur.next()
del row, cur

# write to CSV
gp.AddMessage("\nSummarizing area calculations in CSV...")
gp.AddMessage("CSV Location: "+outputws+"AreaStats_"+ZonesScenarioStr+".csv")
AreaStatsCSV  = open(outputws+"AreaStats_"+ZonesScenarioStr+".csv", "wb")
writer = csv.writer(AreaStatsCSV, delimiter=',', quoting=csv.QUOTE_NONE)
count = -1
while count < gp.GetCount_management(PlanningRegions):
    if count == -1:
        writer.writerow(['ZONE ID', 'ZONE AREA', 'MG LOW', 'MG MED', 'MG HIGH', 'COR LOW', 'COR MED', 'COR HIGH', 'SG LOW', 'SG MED', 'SG HIGH'])
        writer.writerow(['(ID FIELD)', '(SQ. KM)', '(SQ. KM)', '(SQ. KM)', '(SQ. KM)', '(SQ. KM)', '(SQ. KM)', '(SQ. KM)', '(SQ. KM)', '(SQ. KM)', '(SQ. KM)'])
    else:
        writer.writerow(AreaStatsArray[count])
    count += 1
AreaStatsCSV.close()

gp.AddMessage("\nDeleting intermediate files...")
if delIntermediate == 'true':
    gp.workspace = interws
    gp.Delete_management(MangroveDissolve)
    gp.Delete_management(unionMangroveZones)
    gp.Delete_management(CoralDissolve)
    gp.Delete_management(unionCoralZones)
    gp.Delete_management(SeagrassDissolve)
    gp.Delete_management(unionSeagrassZones)
    gp.Delete_management(interws)

# create parameter file
parameters.append("Script location: "+os.path.dirname(sys.argv[0])+"\\"+os.path.basename(sys.argv[0]))
parafile = open(gp.GetParameterAsText(0)+"\\Output\\parameters_"+now.strftime("%Y-%m-%d-%H-%M")+".txt","w") 
parafile.writelines("RISK SUMMARIES TOOL\n")
parafile.writelines("___________________\n\n")
for para in parameters:
    parafile.writelines(para+"\n")
    parafile.writelines("\n")
parafile.close()